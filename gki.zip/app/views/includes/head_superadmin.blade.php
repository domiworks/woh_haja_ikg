
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>GKI</title>

		<!--Identity-->
	
	
		<!-- Style -->
		<link href="{{ asset('assets/css/all.css') }}" rel="stylesheet"><!-- {{ asset('assets/css/all.css') }} -->
		<!--<link href="{{ asset('assets/js/datepicker/css/datepicker.css') }}" rel="stylesheet">-->
		<link href="{{ asset('assets/js/datetimepicker/jquery.datetimepicker.css') }}" rel="stylesheet">
		
		<!-- Loader -->
		<link href="{{ asset('assets/css/loader.css') }}" rel="stylesheet">
		
		
		<!--<link rel="icon" type="image/png" href="assets/img/favicon.png">--> <!-- {{ asset('assets/img/favicon.png') }} -->
		<script src="{{ asset('assets/js/jquery-1.11.1.min.js') }}"></script>
		<script src="{{ asset('assets/js/jquery-migrate-1.2.1.min.js') }}"></script>
		<script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
		<!--<script src="{{ asset('assets/js/datepicker/js/bootstrap-datepicker.js') }}"></script>-->
		<script src="{{ asset('assets/js/datetimepicker/jquery.datetimepicker.js') }}"></script>
		
		
		<!--<script src="{{ asset('assets/js/tinymce/js/tinymce/tinymce.min.js') }}"></script> -->