<section>
	ini adalah header userview GKI
	
	<!-- link ke halaman login -->
	
	
	<!-- link ke halaman register -->
	
</section>