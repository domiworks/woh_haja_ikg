<ul style="margin-top:15px;">
	<!--for ($i = 0; $i < 10; $i++)
	<li>
		<a href="#">{{-- $i --}}</a>
	</li>
	endfor-->
	
	<li>{{HTML::linkRoute('view_inputdata_kebaktian', 'Input Data Kebaktian', '' , array('style'=>'color:white;'))}}</li>
	<li>{{HTML::linkRoute('view_inputdata_anggota', 'Input Data Anggota', '' , array('style'=>'color:white;'))}}</li>
	<li>{{HTML::linkRoute('view_inputdata_baptis', 'Input Data Baptis', '' , array('style'=>'color:white;'))}}</li>
	<li>{{HTML::linkRoute('view_inputdata_atestasi', 'Input Data Atestasi', '' , array('style'=>'color:white;'))}}</li>
	<li>{{HTML::linkRoute('view_inputdata_pernikahan', 'Input Data Pernikahan', '' , array('style'=>'color:white;'))}}</li>
	<li>{{HTML::linkRoute('view_inputdata_kedukaan', 'Input Data Kedukaan', '' , array('style'=>'color:white;'))}}</li>
	<li>{{HTML::linkRoute('view_inputdata_dkh', 'Input Data Dkh', '' , array('style'=>'color:white;'))}}</li>
	
</ul>