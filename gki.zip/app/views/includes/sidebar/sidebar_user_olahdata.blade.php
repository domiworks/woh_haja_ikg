<ul style="margin-top:15px;">
	<!--for ($i = 0; $i < 10; $i++)
	<li>
		<a href="#">{{-- $i --}}</a>
	</li>
	endfor-->
	
	<li>{{HTML::linkRoute('view_olahdata_kebaktian', 'Olah Data Kebaktian', '' , array('style'=>'color:white;'))}}</li>
	<li>{{HTML::linkRoute('view_olahdata_anggota', 'Olah Data Anggota', '' , array('style'=>'color:white;'))}}</li>
	<li>{{HTML::linkRoute('view_olahdata_baptis', 'Olah Data Baptis', '' , array('style'=>'color:white;'))}}</li>
	<li>{{HTML::linkRoute('view_olahdata_atestasi', 'Olah Data Atestasi', '' , array('style'=>'color:white;'))}}</li>
	<li>{{HTML::linkRoute('view_olahdata_pernikahan', 'Olah Data Pernikahan', '' , array('style'=>'color:white;'))}}</li>
	<li>{{HTML::linkRoute('view_olahdata_kedukaan', 'Olah Data Kedukaan', '' , array('style'=>'color:white;'))}}</li>
	<li>{{HTML::linkRoute('view_olahdata_dkh', 'Olah Data Dkh', '' , array('style'=>'color:white;'))}}</li>
	
</ul>