@extends('layouts.admin_layout')
@section('content')

<div class="s_content_maindiv" style="overflow: hidden;">
	<!--
	<div class="s_sidebar_main" style="">
		<div>
			include('includes.sidebar.sidebar_admin_inputdata')
		</div>
	</div>
	-->
	<div class="s_main_side" style="">
		<!-- css -->
		<style>

		</style>
		<!-- end css -->		
	
		<div class="s_content">
			<div class="container-fluid">
				(DASHBOARD)					
			</div>			
		</div>
	</div>
</div>	
@stop