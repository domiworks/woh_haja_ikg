@extends('layouts.adminlayout')
@section('content')
	ini halaman home adminpanel
@stop