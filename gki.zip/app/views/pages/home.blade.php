@extends('layouts.default')
@section('content')

	ini adalah content home
	
@stop